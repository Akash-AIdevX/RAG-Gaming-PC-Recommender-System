import os
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from .models import PCPart

def create_vector_store():
    parts = PCPart.objects.all()
    texts = [f"{p.name}, Category: {p.category}, Price: {p.price}, Performance: {p.performance_score}" for p in parts]
    embeddings = OpenAIEmbeddings(openai_api_key=os.getenv("OPENAI_API_KEY"))
    vectorstore = FAISS.from_texts(texts, embeddings)
    vectorstore.save_local("pc_vector_store")
    return vectorstore

def load_vector_store():
    embeddings = OpenAIEmbeddings(openai_api_key=os.getenv("OPENAI_API_KEY"))
    return FAISS.load_local("pc_vector_store", embeddings)