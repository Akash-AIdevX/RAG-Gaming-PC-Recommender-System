# recommender/views.py

from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .query_faiss import query_text

@api_view(["POST"])
def recommend_pc(request):
    try:
        query = request.data.get("query")
        k_str = request.data.get("k", "5")
        max_price_str = request.data.get("max_price")

        if not query:
            return Response({"error": "Query text is required"}, status=status.HTTP_400_BAD_REQUEST)
        k = int(k_str)
        max_price = float(max_price_str) if max_price_str else None
        results = query_text(query=query, top_k=k, max_price=max_price)

        return Response({
            "query": query,
            "count": len(results),
            "results": results
        })

    except ValueError:
        return Response({"error": "Invalid number format for k or max_price."}, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        print(f"Error in recommend_pc view: {e}")
        return Response({"error": "An internal server error occurred."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

def ui_view(request):
    """Renders the main user interface."""
    return render(request, 'recommender/index.html')