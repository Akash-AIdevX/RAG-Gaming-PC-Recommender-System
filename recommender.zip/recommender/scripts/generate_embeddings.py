import os
import django
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "rag_gaming_pc.settings")
django.setup()

from recommender.models import PCPart
model = SentenceTransformer('all-MiniLM-L6-v2')
pcs = PCPart.objects.all()

embeddings = []
ids = []

for pc in pcs:
    text = f"SKU: {pc.sku}. CPU: {pc.cpu}, GPU: {pc.gpu}, RAM: {pc.ram}, Storage: {pc.storage}, Price: {pc.price} CAD."
    
    pc.specs_text = text
    pc.save()

    emb = model.encode([text])[0]
    embeddings.append(emb)
    ids.append(pc.id)

embeddings = np.array(embeddings).astype('float32')
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(embeddings)
faiss.write_index(index, "faiss_index.bin")
np.save("ids.npy", np.array(ids))

print(f"✅ FAISS index created with {len(ids)} PCs")
