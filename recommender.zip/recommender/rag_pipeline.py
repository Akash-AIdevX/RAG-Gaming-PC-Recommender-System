# recommender/rag_pipeline.py
import os, sys, json
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(PROJECT_ROOT)

# set Django settings (adjust name if different)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'rag_gaming_pc.settings')
import django
django.setup()

from recommender.query_faiss import query_text
from recommender.models import PCPart

# Optional: call OpenAI if available
try:
    import openai
except Exception:
    openai = None

OPENAI_KEY = os.environ.get("OPENAI_API_KEY", None)
if openai and OPENAI_KEY:
    openai.api_key = OPENAI_KEY

# --- OPTIONAL: deterministic price recomputation function (if needed) ---
def recompute_price(pc: PCPart, ssd_override=None, monitor_override=None):
    """
    Use stored pc.base fields if exists; fallback to pc.price.
    Rules implemented:
      - SSD: 2S => +70
      - Monitor: _24 => +110, _27 => +180
    Returns float price.
    """
    base = getattr(pc, "base_gpu_price", None) or getattr(pc, "price", 0.0)
    ssd = ssd_override or getattr(pc, "ssd", None) or "1S"
    monitor = monitor_override or getattr(pc, "monitor", None)
    ssd_add = 70.0 if str(ssd).upper() == "2S" else 0.0
    monitor_add = 0.0
    if monitor in ("24", "_24", '24"'):
        monitor_add = 110.0
    if monitor in ("27", "_27", '27"'):
        monitor_add = 180.0
    return round(float(base) + ssd_add + monitor_add, 2)

# --- Compose context for LLM ---
def build_context_snippets(items, max_chars=1500):
    """
    Items is list of dicts with 'specs_text' from query_faiss.
    Keep total context short (LLM token limits). Truncate long specs.
    """
    snippets = []
    total = 0
    for it in items:
        txt = it.get("specs_text", "")
        if len(txt) > max_chars:
            txt = txt[:max_chars] + "..."
        snippets.append(f"{it.get('sku')} — {txt} — Price: {it.get('price')}")
        total += len(txt)
        if total > (max_chars * 4):  # safety break
            break
    return "\n\n".join(snippets)
def template_answer(query, items):
    if not items:
        return "I couldn't find any PCs matching your request."
    cad_to_inr = 61  

    lines = [f"Top {len(items)} matching PCs for: \"{query}\""]
    for it in items:
        price_cad = float(it.get('price', 0.0))
        price_inr = price_cad * cad_to_inr
        price_str = f"₹{price_inr:,.0f} INR"

        lines.append(
            f"- {it['name']} (SKU: {it['sku']}), Price: {price_str}. Specs: {it['specs_text']}"
        )
    return "\n".join(lines)

def call_llm_with_context(query, items, model="gpt-3.5-turbo", temperature=0.2, max_tokens=400):
    if openai is None or OPENAI_KEY is None:
        raise RuntimeError("OpenAI not configured. Set OPENAI_API_KEY environment variable and install openai.")

    context = build_context_snippets(items)
    system = (
        "You are an assistant that recommends gaming PCs. Use only the provided context and facts. "
        "When asked for budget recommendations, return 1-3 suggestions and justify briefly. "
        "At the end, provide a JSON array named 'skus' containing the recommended SKUs only."
    )
    user_message = f"Context:\n{context}\n\nUser query: {query}\n\nAnswer concisely and include the JSON array of skus."
    resp = openai.ChatCompletion.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user_message}
        ],
        temperature=temperature,
        max_tokens=max_tokens
    )
    return resp['choices'][0]['message']['content'].strip()

# --- Main pipeline function ---
def rag_answer(query, top_k=5, max_price=None, use_llm=False):
    # Step 1: retrieve with FAISS (this returns list of dicts from query_faiss)
    items = query_text(query, top_k=top_k, max_price=max_price)

    # Step 2: optionally recompute deterministic prices (example - not mandatory)
    for it in items:
        try:
            pc = PCPart.objects.get(sku=it['sku'])
            it['computed_price'] = recompute_price(pc)
        except PCPart.DoesNotExist:
            it['computed_price'] = it.get('price')

    # Step 3: return either templated or LLM answer
    if use_llm:
        try:
            answer = call_llm_with_context(query, items)
        except Exception as e:
            # fallback to template if LLM fails
            answer = f"(LLM failed: {e})\n\n" + template_answer(query, items)
    else:
        answer = template_answer(query, items)

    return {"answer": answer, "matches": items}

# --- CLI run for quick test ---
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('query', nargs='+')
    parser.add_argument('--k', type=int, default=5)
    parser.add_argument('--max_price', type=float, default=None)
    parser.add_argument('--use_llm', action='store_true')
    args = parser.parse_args()
    q = " ".join(args.query)
    out = rag_answer(q, top_k=args.k, max_price=args.max_price, use_llm=args.use_llm)
    print("=== ANSWER ===")
    print(out['answer'])
    print("\n=== MATCHED SKUs ===")
    for m in out['matches']:
        print(m['sku'], "| price:", m.get('computed_price') or m.get('price'))
