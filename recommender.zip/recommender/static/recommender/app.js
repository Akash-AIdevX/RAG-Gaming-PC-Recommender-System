document.addEventListener("DOMContentLoaded", () => {
    const searchBtn = document.getElementById("searchBtn");
    const queryInput = document.getElementById("query");
    const priceInput = document.getElementById("max_price");
    const kInput = document.getElementById("k");
    const resultsGrid = document.getElementById("results");
    const loader = document.getElementById("loader");

    // Function to fetch CSRF token from cookies
    function getCSRFToken() {
        let csrfToken = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, 'csrftoken'.length + 1) === ('csrftoken=')) {
                    csrfToken = decodeURIComponent(cookie.substring('csrftoken'.length + 1));
                    break;
                }
            }
        }
        return csrfToken;
    }

    const performSearch = async () => {
        const query = queryInput.value;
        const max_price = priceInput.value;
        const k = kInput.value;

        // Show loader and clear previous results
        resultsGrid.innerHTML = "";
        loader.style.display = "flex";

        try {
            const response = await fetch("/recommender/search/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRFToken": getCSRFToken()
                },
                body: JSON.stringify({ query, max_price, k })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();
            
            // Hide loader
            loader.style.display = "none";

            if (data.results && data.results.length > 0) {
                data.results.forEach(item => {
                    const card = document.createElement("div");
                    card.className = "card";
                    card.innerHTML = `
                        <h3 class="card-title">${item.name}</h3>
                        <p class="card-price">₹ ${parseInt(item.price).toLocaleString("en-IN")}</p>
                        
                        <div class="card-specs">
                            <h4>Key Specifications</h4>
                            <p>${item.specs_text}</p>
                        </div>

                        <div class="card-footer">
                            <span>SKU: ${item.sku}</span>
                            <span class="score-badge">Match: ${item.score.toFixed(2)}</span>
                        </div>
                    `;
                    resultsGrid.appendChild(card);
                });
            } else {
                resultsGrid.innerHTML = `<p style="grid-column: 1 / -1; text-align: center; color: var(--color-text-secondary);">😕 No matching PCs found. Try adjusting your search or budget.</p>`;
            }
        } catch (err) {
            // Hide loader and show error
            loader.style.display = "none";
            resultsGrid.innerHTML = `<p style='color: #F87171; grid-column: 1 / -1; text-align: center;'>An error occurred: ${err.message}. Please try again.</p>`;
            console.error("Search Error:", err);
        }
    };

    searchBtn.addEventListener("click", performSearch);

    // Optional: Allow search on pressing Enter in the query input
    queryInput.addEventListener("keyup", (event) => {
        if (event.key === "Enter") {
            performSearch();
        }
    });
});