from django.urls import path
from .views import recommend_pc, ui_view 

urlpatterns = [
    path('search/', recommend_pc, name='api_search'),
    path('', ui_view, name='recommender_home'),
]