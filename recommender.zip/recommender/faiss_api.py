# recommender/faiss_api.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .query_faiss import query_text

@csrf_exempt
def search_view(request):
    q = request.GET.get('q', '')
    k = int(request.GET.get('k', 5))
    max_price = request.GET.get('max_price')
    if max_price:
        try: max_price = float(max_price)
        except: max_price = None
    results = query_text(q, top_k=k, max_price=max_price)
    return JsonResponse({'query': q, 'results': results})
