# recommender/faiss_utils.py
import os, sys
import numpy as np
import faiss

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
INDEX_PATH = os.path.join(PROJECT_ROOT, 'faiss_index.bin')
IDS_PATH = os.path.join(PROJECT_ROOT, 'ids.npy')
_index = None
_ids = None

def load_index_and_ids(index_path=INDEX_PATH, ids_path=IDS_PATH):
    global _index, _ids
    if _index is None:
        if not os.path.exists(index_path):
            raise FileNotFoundError(f"FAISS index not found at {index_path}")
        _index = faiss.read_index(index_path)
    if _ids is None:
        if not os.path.exists(ids_path):
            raise FileNotFoundError(f"IDs file not found at {ids_path}")
        _ids = np.load(ids_path)
    return _index, _ids

def index_info():
    idx, ids = load_index_and_ids()
    info = {
        'ntotal': int(idx.ntotal),
        'ids_count': int(len(ids))
    }
    try:
        info['dim'] = int(idx.d)
    except Exception:
        info['dim'] = None
    return info
