# recommender/build_faiss.py
import os, sys, json
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(PROJECT_ROOT)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'rag_gaming_pc.settings')
import django
django.setup()

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from recommender.models import PCPart
from recommender.faiss_utils import INDEX_PATH, IDS_PATH

MODEL_NAME = "all-MiniLM-L6-v2"
METADATA_PATH = os.path.join(PROJECT_ROOT, "recommender", "pc_metadata.json")

def build_index():
    model = SentenceTransformer(MODEL_NAME)

    pcs = PCPart.objects.all()
    texts, ids, metadata = [], [], {}

    for pc in pcs:
        spec = f"SKU: {pc.sku}, CPU: {pc.cpu}, GPU: {pc.gpu}, RAM: {pc.ram}, Storage: {pc.storage}, Price: {pc.price}, {pc.description or ''}"
        texts.append(spec)
        ids.append(pc.pk)

        metadata[pc.pk] = {
            "sku": pc.sku,
            "cpu": pc.cpu,
            "gpu": pc.gpu,
            "ram": pc.ram,
            "storage": pc.storage,
            "price": float(pc.price),
            "description": pc.description or ""
        }

    if not texts:
        print("⚠️ No PC parts found in DB to index.")
        return

    embeddings = model.encode(texts, convert_to_numpy=True).astype('float32')

    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    faiss.normalize_L2(embeddings)
    index.add(embeddings)

    # Save FAISS index
    faiss.write_index(index, INDEX_PATH)
    np.save(IDS_PATH, np.array(ids))

    # Save metadata as JSON
    with open(METADATA_PATH, "w") as f:
        json.dump(metadata, f)

    print(f"✅ Built FAISS index with {len(ids)} items")
    print(f"Saved to {INDEX_PATH}, {IDS_PATH}, and {METADATA_PATH}")

if __name__ == "__main__":
    build_index()
