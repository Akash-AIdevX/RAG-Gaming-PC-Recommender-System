import os, sys
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(PROJECT_ROOT)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'rag_gaming_pc.settings')
import django
django.setup()

import numpy as np
from sentence_transformers import SentenceTransformer
from recommender.faiss_utils import load_index_and_ids
from recommender.models import PCPart

MODEL_NAME = "all-MiniLM-L6-v2"
_model = None

def get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(MODEL_NAME)
    return _model

def query_text(query, top_k=5, max_price=None):
    model = get_model()
    q_emb = model.encode([query], convert_to_numpy=True).astype('float32')

    # normalize query too
    import faiss
    faiss.normalize_L2(q_emb)

    index, ids = load_index_and_ids()
    D, I = index.search(q_emb, top_k)

    results = []
    for dist, pos in zip(D[0], I[0]):
        if pos < 0:
            continue
        try:
            pk = int(ids[pos])
            pc = PCPart.objects.get(pk=pk)
        except Exception:
            continue
        results.append({
            'sku': pc.sku,
            'name': getattr(pc, 'name', '') or pc.sku,
            'price': pc.price,
            'specs_text': pc.specs_text,
            'score': float(dist)
        })

    # filter by max price strictly
    if max_price is not None:
        results = [r for r in results if r['price'] <= max_price]

    return results

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('query', nargs='+', help='Query text (wrap in quotes)')
    parser.add_argument('--k', type=int, default=5)
    parser.add_argument('--max_price', type=float, default=None)
    args = parser.parse_args()
    q = " ".join(args.query)
    res = query_text(q, top_k=args.k, max_price=args.max_price)
    if not res:
        print("No results found. Check index, ids, and DB.")
    for r in res:
        print(f"{r['sku']} | {r['name']} | {r['price']} CAD | score={r['score']}")
        print(r['specs_text'])
        print("-" * 60)
