# recommender/management/commands/import_parts.py
import csv
from django.core.management.base import BaseCommand
from recommender.models import PCPart

class Command(BaseCommand):
    help = "Import PC parts from CSV"

    def handle(self, *args, **kwargs):
        with open("pc_parts.csv", newline='', encoding="utf-8") as csvfile:
            reader = csv.DictReader(csvfile)
            count = 0
            for row in reader:
                pc, created = PCPart.objects.update_or_create(
                    sku=row["sku"],  # unique key
                    defaults={
                        "name": row["name"],
                        "cpu": row["cpu"],
                        "gpu": row["gpu"],
                        "ram": row["ram"],
                        "storage": row["storage"],
                        "price": float(row["price"]),
                        "description": row.get("description", ""),
                        "specs_text": f"SKU: {row['sku']}, CPU: {row['cpu']}, GPU: {row['gpu']}, "
                                      f"RAM: {row['ram']}, Storage: {row['storage']}, "
                                      f"Price: {row['price']} CAD, {row.get('description','')}"
                    }
                )
                count += 1
        self.stdout.write(self.style.SUCCESS(f"Imported {count} PC parts successfully"))
