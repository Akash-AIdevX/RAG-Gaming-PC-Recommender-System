from django.db import models

class PCPart(models.Model):
    sku = models.CharField(max_length=255, blank=True, null=True, default="temp_sku")
    name = models.CharField(max_length=255, blank=True, null=True)
    cpu = models.CharField(max_length=255, blank=True, null=True)
    gpu = models.CharField(max_length=255, blank=True, null=True)
    ram = models.CharField(max_length=255, default="32GB")
    storage = models.CharField(max_length=255, default="1TB SSD")
    price = models.FloatField(default=0.0)
    description = models.TextField(blank=True, null=True)
    specs_text = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.sku
