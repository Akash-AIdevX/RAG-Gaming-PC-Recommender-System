# rag_gaming_pc/urls.py

from django.contrib import admin
from django.urls import path, include
from recommender.views import ui_view # Import your UI view

# rag_gaming_pc/urls.py
# rag_gaming_pc/urls.py
from django.contrib import admin
from django.urls import path, include
# REMOVE this import: from recommender.views import ui_view

urlpatterns = [
    path('admin/', admin.site.urls),
    # The line that was here is now gone.
    path('recommender/', include('recommender.urls')),
]